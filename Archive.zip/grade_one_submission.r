# load in the package
library(gradeR)

calcGradesForGradescope("Lesson_10_Assignment_Hypothesis_Testing_Plus.R",       # each student's submission must be named this!
                        "Lesson_10_Assignment_Tests.R") # the file with all of the testthat tests 
  
